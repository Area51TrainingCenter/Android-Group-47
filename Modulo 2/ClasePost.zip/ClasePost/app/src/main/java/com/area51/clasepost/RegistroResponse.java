package com.area51.clasepost;

public class RegistroResponse {
    private String nomServ;
    private int codRpta;
    private String desRpta;

    public String getNomServ() {
        return nomServ;
    }

    public void setNomServ(String nomServ) {
        this.nomServ = nomServ;
    }

    public int getCodRpta() {
        return codRpta;
    }

    public void setCodRpta(int codRpta) {
        this.codRpta = codRpta;
    }

    public String getDesRpta() {
        return desRpta;
    }

    public void setDesRpta(String desRpta) {
        this.desRpta = desRpta;
    }
}
